from pathlib import Path

DATA_DIR = Path('/home/joris/data')
